﻿//EJERCICIO 1
/*
Coche coche1 = new Coche(2022,"SPORTMAN","HYNDAI");
coche1.Acelerar();
*/

//EJERCICIO2
Coche coche2 = new Coche(2002,"SPORTMAN","HYNDAI", 25);
//ACELERAR
coche2.Acelerar(10);
int velocidadCoche = coche2.GetVelocidadActual();
Console.WriteLine($"La velocidad actual del coche es {velocidadCoche}");
//FRENAR
coche2.Frenar(5);
Console.WriteLine($"La velocidad actual del coche es {velocidadCoche}");
//LLENADOCOMBUSTIBLE
coche2.LlenarTanque(25);
coche2.LlenarTanque(10);