using System.Security.AccessControl;

public class Coche{
    private const double CAPACIDAD_COMBUSTIBLE = 50;
    private int anio, velocidadActual, incremento , decremento;
    private double combustible;
    private string marca, modelo;

    public Coche(){
        anio = 0;
        marca = string.Empty;
        modelo = string.Empty;
        combustible = 0;
    }

    public Coche(int anio, string marca, string modelo, double combustible){
        this.anio = anio;
        this.marca = marca;
        this.modelo = modelo;
        this.combustible = combustible;
    }

    public double GetCombustible(){
        return combustible;
    }

    public void SetCombustible(double combustible){
        this.combustible = combustible;
    }

    public int GetVelocidadActual(){
        return velocidadActual;
    }


    public void SetVelocidadActural(int velocidadActual){
        this.velocidadActual = velocidadActual;
    }

    public int Acelerar(int incremento){
        Console.WriteLine("----------");
        Console.WriteLine("El coche esta acelerando...");
        SetVelocidadActural(incremento);
        return GetVelocidadActual();
    }

    public int Frenar(int decremento){
        int cantidadVelocidad = GetVelocidadActual();
        if(cantidadVelocidad > 0){
            Console.WriteLine("----------");
            Console.WriteLine("El coche esta frenando...");
            int totalKilometraje = cantidadVelocidad - decremento;
            SetVelocidadActural(totalKilometraje);
            return cantidadVelocidad;
        }else{
            Console.WriteLine("----------");
            Console.WriteLine("El coche esta quieto");
            return cantidadVelocidad;
        }
    }

    public double LlenarTanque(double combustible){
        double cantidadCombustible = GetCombustible();
        if(CAPACIDAD_COMBUSTIBLE > cantidadCombustible){
            Console.WriteLine("----------");
            Console.WriteLine("Añadiendo combustible al coche...");
            double totalCombustible = cantidadCombustible + combustible;
            SetCombustible(totalCombustible);
            Console.WriteLine($"Su tanque de combustible posee {cantidadCombustible}");
            return cantidadCombustible;
        }else{
            Console.WriteLine("----------");
            Console.WriteLine("El coche alcanzo la maxima capacidad de combustible");
            return cantidadCombustible;
        }
    }
}