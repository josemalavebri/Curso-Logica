﻿namespace Practica09092024Reyes
{
    internal class Program
    {
        static void Main(string[] args)
        {
        
            Coche coche = new Coche();
            coche.SetMarca("Vintage");
            coche.SetModelo("Caligeo");
            coche.SetAnio(2019);

            Console.WriteLine("Introduce cuanto de combustible hay actualmente: ");
            double Combustible = Convert.ToInt32(Console.ReadLine());
            coche.SetCombustible(Combustible);



            coche.Acelerar();
            Console.WriteLine("Introduce cuanto de velocidad quiere acelerar: ");
            int incremento = Convert.ToInt32(Console.ReadLine());
            coche.Acelerar(incremento);

            Console.WriteLine("Cuantas unidades de velocidad deseas disminuir para frenar: ");
            int decremento = Convert.ToInt32(Console.ReadLine());
            coche.Frenar(decremento);

            Console.WriteLine("Cuanto es la capacidad limite de combustible al coche: ");
            double CapacidadCombustible = Convert.ToDouble(Console.ReadLine());
            coche.SetCapacidadCombustible(CapacidadCombustible);

            Console.WriteLine("Cuantos litros de combustibles quieres anadir al coche: ");
            double litros = Convert.ToDouble(Console.ReadLine());
            
            coche.Repostar(litros);

            GestorCoche gestorcoche = new GestorCoche(coche);

            gestorcoche.mostrarInformacion();




        }

    }
}
