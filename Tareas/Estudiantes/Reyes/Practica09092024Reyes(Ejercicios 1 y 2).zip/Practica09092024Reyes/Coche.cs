﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica09092024Reyes
{
    public class Coche
    {
        private string Marca;
        private string Modelo;
        private int Anio;
        private int VelocidadActual;
        private double Combustible;
        private double CapacidadCombustible;
        
        public Coche() { 
            this.Marca = string.Empty;
            this.Modelo = string.Empty;
            this.Anio = 0;
            this.VelocidadActual = 0;
            this.Combustible = 0;
            this.CapacidadCombustible = 0;
        }

        public Coche(string Marca, string Modelo, int Anio, int VelocidadActual, double Combustible, double CapacidadCombustible) { 
            this.Marca= Marca;
            this.Modelo= Modelo;
            this.Anio= Anio;
            this.VelocidadActual= VelocidadActual;
            this.Combustible= Combustible;
            this.CapacidadCombustible = CapacidadCombustible;
        }


        public void Acelerar()
        {
            Console.WriteLine($"El coche esta empezando acelerar");
        }

        public void Acelerar(int incremento)
        {

            if (Combustible >= 5)
            {
                Console.WriteLine($"El coche esta acelerando");
                for (int i = 1; i <= incremento; i++)
                {
                    VelocidadActual += 1;
                    Console.WriteLine($"Acelerando... velocidad actual: {VelocidadActual}");
                    Combustible -= 1;

                    if (Combustible <= 0)
                    {
                        Console.WriteLine("El coche se ha quedado sin combustible. No puede seguir acelerando.");
                        break;
                    }
                }

                Console.WriteLine("El combustible ahora es: " + Combustible);
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("No hay suficiente combustible disponible para comenzar a acelerar");
            }
        }

        public void Frenar(int decremento)
        {
            if (VelocidadActual > 0)
            {
                Console.WriteLine($"");
                for (int i = 0; i < decremento && VelocidadActual > 0; i++)
                {
                    VelocidadActual--;
                    Console.WriteLine($"El coche esta frenando, velocidad actual: {VelocidadActual}");

                    if (VelocidadActual == 0)
                    {
                        Console.WriteLine($"El coche freno completamente");
                        break;
                    }
                }

                Console.WriteLine("La velocidad ahora es: " + VelocidadActual);
                Console.WriteLine("");

            }
            else
            {
                Console.WriteLine("Frenado");
            }
        }

        public void Repostar(double litros)
        {
            if (Combustible >= CapacidadCombustible)
            {
                Console.WriteLine($"El tanque esta lleno no se puede llenar mas");
                Console.WriteLine($"");
            }
            else
            {
                for (int i = 1; i <= litros && Combustible < CapacidadCombustible; i++)
                {
                    Combustible++;
                    Console.WriteLine($"Anadiendo combustible al coche: {Combustible}");
                    if (Combustible == CapacidadCombustible)
                    {
                        Console.WriteLine("El tanque esta lleno");
                        break;
                    }
                }

                Console.WriteLine("El combustible que tiene el coche ahora es: " + Combustible);
                Console.WriteLine("");
            }


        }

        public string GetMarca() { 
            return this.Marca;
        }

        public string GetModelo() {
            return this.Modelo;
        }
        public int GetAnio() {
            return this.Anio;
        }

        public double GetCombustible() { 
            return this.Combustible;
        }

        public int GetVelocidadActual()
        {
            return this.VelocidadActual;
        }

        public double GetCapacidadCombustible()
        {
            return this.CapacidadCombustible;
        }

        public void SetMarca(string Marca) {
            this.Marca = Marca;
        }

        public void SetModelo(string Modelo) {
            this.Modelo = Modelo;
        }

        public void SetAnio(int Anio) {
            this.Anio = Anio;
        }

        public void SetCombustible(double Combustible) { 
            this.Combustible = Combustible;
        }

        public void SetVelocidadActual(int VelocidadActual) { 
            this.VelocidadActual = VelocidadActual;
        }

        public void SetCapacidadCombustible(double CapacidadCombustible) { 
            this.CapacidadCombustible = CapacidadCombustible;
        }


    }
}
