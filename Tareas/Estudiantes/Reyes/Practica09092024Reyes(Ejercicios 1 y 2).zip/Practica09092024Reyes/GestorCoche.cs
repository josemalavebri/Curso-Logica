﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica09092024Reyes
{
    internal class GestorCoche
    {
        private Coche coche;

        public GestorCoche(Coche coche)
        {
            this.coche = coche;
        }

        public void mostrarInformacion() { 
        
            string Marca= coche.GetMarca();
            string Modelo= coche.GetModelo();
            int Anio = coche.GetAnio();
            double Combustible = coche.GetCombustible();
            int VelocidadActual = coche.GetVelocidadActual();
            double CapacidadCombustible = coche.GetCapacidadCombustible();

            Console.WriteLine($"La marca del coche es: {Marca}");
            Console.WriteLine($"El modelo del coche es: {Modelo}");
            Console.WriteLine($"El anio de origen del coche es: {Anio}");
            Console.WriteLine($"El combustible actual del coche es: {Combustible}");
            Console.WriteLine($"La velocidad actual del coche es: {VelocidadActual}");
            Console.WriteLine($"La maxima capacidad de combustible del coche es: {CapacidadCombustible}");

        }




    }
}
